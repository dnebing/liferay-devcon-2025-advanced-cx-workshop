const Z=globalThis,lt=Z.ShadowRoot&&(Z.ShadyCSS===void 0||Z.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,kt=Symbol(),ft=new WeakMap;let Zt=class{constructor(t,e,s){if(this._$cssResult$=!0,s!==kt)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(lt&&t===void 0){const s=e!==void 0&&e.length===1;s&&(t=ft.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),s&&ft.set(e,t))}return t}toString(){return this.cssText}};const Gt=r=>new Zt(typeof r=="string"?r:r+"",void 0,kt),Qt=(r,t)=>{if(lt)r.adoptedStyleSheets=t.map((e=>e instanceof CSSStyleSheet?e:e.styleSheet));else for(const e of t){const s=document.createElement("style"),i=Z.litNonce;i!==void 0&&s.setAttribute("nonce",i),s.textContent=e.cssText,r.appendChild(s)}},_t=lt?r=>r:r=>r instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return Gt(e)})(r):r;const{is:Xt,defineProperty:Yt,getOwnPropertyDescriptor:te,getOwnPropertyNames:ee,getOwnPropertySymbols:se,getPrototypeOf:ie}=Object,y=globalThis,gt=y.trustedTypes,re=gt?gt.emptyScript:"",oe=y.reactiveElementPolyfillSupport,L=(r,t)=>r,Q={toAttribute(r,t){switch(t){case Boolean:r=r?re:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,t){let e=r;switch(t){case Boolean:e=r!==null;break;case Number:e=r===null?null:Number(r);break;case Object:case Array:try{e=JSON.parse(r)}catch{e=null}}return e}},ct=(r,t)=>!Xt(r,t),mt={attribute:!0,type:String,converter:Q,reflect:!1,useDefault:!1,hasChanged:ct};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),y.litPropertyMetadata??(y.litPropertyMetadata=new WeakMap);let N=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??(this.l=[])).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=mt){if(e.state&&(e.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((e=Object.create(e)).wrapped=!0),this.elementProperties.set(t,e),!e.noAccessor){const s=Symbol(),i=this.getPropertyDescriptor(t,s,e);i!==void 0&&Yt(this.prototype,t,i)}}static getPropertyDescriptor(t,e,s){const{get:i,set:o}=te(this.prototype,t)??{get(){return this[e]},set(n){this[e]=n}};return{get:i,set(n){const l=i?.call(this);o?.call(this,n),this.requestUpdate(t,l,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??mt}static _$Ei(){if(this.hasOwnProperty(L("elementProperties")))return;const t=ie(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(L("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(L("properties"))){const e=this.properties,s=[...ee(e),...se(e)];for(const i of s)this.createProperty(i,e[i])}const t=this[Symbol.metadata];if(t!==null){const e=litPropertyMetadata.get(t);if(e!==void 0)for(const[s,i]of e)this.elementProperties.set(s,i)}this._$Eh=new Map;for(const[e,s]of this.elementProperties){const i=this._$Eu(e,s);i!==void 0&&this._$Eh.set(i,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const s=new Set(t.flat(1/0).reverse());for(const i of s)e.unshift(_t(i))}else t!==void 0&&e.push(_t(t));return e}static _$Eu(t,e){const s=e.attribute;return s===!1?void 0:typeof s=="string"?s:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach((t=>t(this)))}addController(t){(this._$EO??(this._$EO=new Set)).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const s of e.keys())this.hasOwnProperty(s)&&(t.set(s,this[s]),delete this[s]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return Qt(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),this._$EO?.forEach((t=>t.hostConnected?.()))}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach((t=>t.hostDisconnected?.()))}attributeChangedCallback(t,e,s){this._$AK(t,s)}_$ET(t,e){const s=this.constructor.elementProperties.get(t),i=this.constructor._$Eu(t,s);if(i!==void 0&&s.reflect===!0){const o=(s.converter?.toAttribute!==void 0?s.converter:Q).toAttribute(e,s.type);this._$Em=t,o==null?this.removeAttribute(i):this.setAttribute(i,o),this._$Em=null}}_$AK(t,e){const s=this.constructor,i=s._$Eh.get(t);if(i!==void 0&&this._$Em!==i){const o=s.getPropertyOptions(i),n=typeof o.converter=="function"?{fromAttribute:o.converter}:o.converter?.fromAttribute!==void 0?o.converter:Q;this._$Em=i;const l=n.fromAttribute(e,o.type);this[i]=l??this._$Ej?.get(i)??l,this._$Em=null}}requestUpdate(t,e,s){if(t!==void 0){const i=this.constructor,o=this[t];if(s??(s=i.getPropertyOptions(t)),!((s.hasChanged??ct)(o,e)||s.useDefault&&s.reflect&&o===this._$Ej?.get(t)&&!this.hasAttribute(i._$Eu(t,s))))return;this.C(t,e,s)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(t,e,{useDefault:s,reflect:i,wrapped:o},n){s&&!(this._$Ej??(this._$Ej=new Map)).has(t)&&(this._$Ej.set(t,n??e??this[t]),o!==!0||n!==void 0)||(this._$AL.has(t)||(this.hasUpdated||s||(e=void 0),this._$AL.set(t,e)),i===!0&&this._$Em!==t&&(this._$Eq??(this._$Eq=new Set)).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[i,o]of this._$Ep)this[i]=o;this._$Ep=void 0}const s=this.constructor.elementProperties;if(s.size>0)for(const[i,o]of s){const{wrapped:n}=o,l=this[i];n!==!0||this._$AL.has(i)||l===void 0||this.C(i,void 0,o,l)}}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach((s=>s.hostUpdate?.())),this.update(e)):this._$EM()}catch(s){throw t=!1,this._$EM(),s}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach((e=>e.hostUpdated?.())),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&(this._$Eq=this._$Eq.forEach((e=>this._$ET(e,this[e])))),this._$EM()}updated(t){}firstUpdated(t){}};N.elementStyles=[],N.shadowRootOptions={mode:"open"},N[L("elementProperties")]=new Map,N[L("finalized")]=new Map,oe?.({ReactiveElement:N}),(y.reactiveElementVersions??(y.reactiveElementVersions=[])).push("2.1.1");const D=globalThis,X=D.trustedTypes,At=X?X.createPolicy("lit-html",{createHTML:r=>r}):void 0,Rt="$lit$",m=`lit$${Math.random().toFixed(9).slice(2)}$`,Lt="?"+m,ne=`<${Lt}>`,C=document,Y=()=>C.createComment(""),W=r=>r===null||typeof r!="object"&&typeof r!="function",dt=Array.isArray,he=r=>dt(r)||typeof r?.[Symbol.iterator]=="function",rt=`[ 	
\f\r]`,k=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,yt=/-->/g,vt=/>/g,b=RegExp(`>|${rt}(?:([^\\s"'>=/]+)(${rt}*=${rt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),bt=/'/g,Et=/"/g,Dt=/^(?:script|style|textarea|title)$/i,U=Symbol.for("lit-noChange"),p=Symbol.for("lit-nothing"),St=new WeakMap,S=C.createTreeWalker(C,129);function jt(r,t){if(!dt(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return At!==void 0?At.createHTML(t):t}const ae=(r,t)=>{const e=r.length-1,s=[];let i,o=t===2?"<svg>":t===3?"<math>":"",n=k;for(let l=0;l<e;l++){const h=r[l];let c,d,a=-1,u=0;for(;u<h.length&&(n.lastIndex=u,d=n.exec(h),d!==null);)u=n.lastIndex,n===k?d[1]==="!--"?n=yt:d[1]!==void 0?n=vt:d[2]!==void 0?(Dt.test(d[2])&&(i=RegExp("</"+d[2],"g")),n=b):d[3]!==void 0&&(n=b):n===b?d[0]===">"?(n=i??k,a=-1):d[1]===void 0?a=-2:(a=n.lastIndex-d[2].length,c=d[1],n=d[3]===void 0?b:d[3]==='"'?Et:bt):n===Et||n===bt?n=b:n===yt||n===vt?n=k:(n=b,i=void 0);const f=n===b&&r[l+1].startsWith("/>")?" ":"";o+=n===k?h+ne:a>=0?(s.push(c),h.slice(0,a)+Rt+h.slice(a)+m+f):h+m+(a===-2?l:f)}return[jt(r,o+(r[e]||"<?>")+(t===2?"</svg>":t===3?"</math>":"")),s]};let nt=class It{constructor({strings:t,_$litType$:e},s){let i;this.parts=[];let o=0,n=0;const l=t.length-1,h=this.parts,[c,d]=ae(t,e);if(this.el=It.createElement(c,s),S.currentNode=this.el.content,e===2||e===3){const a=this.el.content.firstChild;a.replaceWith(...a.childNodes)}for(;(i=S.nextNode())!==null&&h.length<l;){if(i.nodeType===1){if(i.hasAttributes())for(const a of i.getAttributeNames())if(a.endsWith(Rt)){const u=d[n++],f=i.getAttribute(a).split(m),_=/([.?@])?(.*)/.exec(u);h.push({type:1,index:o,name:_[2],strings:f,ctor:_[1]==="."?ce:_[1]==="?"?de:_[1]==="@"?pe:et}),i.removeAttribute(a)}else a.startsWith(m)&&(h.push({type:6,index:o}),i.removeAttribute(a));if(Dt.test(i.tagName)){const a=i.textContent.split(m),u=a.length-1;if(u>0){i.textContent=X?X.emptyScript:"";for(let f=0;f<u;f++)i.append(a[f],Y()),S.nextNode(),h.push({type:2,index:++o});i.append(a[u],Y())}}}else if(i.nodeType===8)if(i.data===Lt)h.push({type:2,index:o});else{let a=-1;for(;(a=i.data.indexOf(m,a+1))!==-1;)h.push({type:7,index:o}),a+=m.length-1}o++}}static createElement(t,e){const s=C.createElement("template");return s.innerHTML=t,s}};function H(r,t,e=r,s){if(t===U)return t;let i=s!==void 0?e._$Co?.[s]:e._$Cl;const o=W(t)?void 0:t._$litDirective$;return i?.constructor!==o&&(i?._$AO?.(!1),o===void 0?i=void 0:(i=new o(r),i._$AT(r,e,s)),s!==void 0?(e._$Co??(e._$Co=[]))[s]=i:e._$Cl=i),i!==void 0&&(t=H(r,i._$AS(r,t.values),i,s)),t}let le=class{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:s}=this._$AD,i=(t?.creationScope??C).importNode(e,!0);S.currentNode=i;let o=S.nextNode(),n=0,l=0,h=s[0];for(;h!==void 0;){if(n===h.index){let c;h.type===2?c=new zt(o,o.nextSibling,this,t):h.type===1?c=new h.ctor(o,h.name,h.strings,this,t):h.type===6&&(c=new ue(o,this,t)),this._$AV.push(c),h=s[++l]}n!==h?.index&&(o=S.nextNode(),n++)}return S.currentNode=C,i}p(t){let e=0;for(const s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(t,s,e),e+=s.strings.length-2):s._$AI(t[e])),e++}},zt=class Bt{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,s,i){this.type=2,this._$AH=p,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=s,this.options=i,this._$Cv=i?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return e!==void 0&&t?.nodeType===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=H(this,t,e),W(t)?t===p||t==null||t===""?(this._$AH!==p&&this._$AR(),this._$AH=p):t!==this._$AH&&t!==U&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):he(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==p&&W(this._$AH)?this._$AA.nextSibling.data=t:this.T(C.createTextNode(t)),this._$AH=t}$(t){const{values:e,_$litType$:s}=t,i=typeof s=="number"?this._$AC(t):(s.el===void 0&&(s.el=nt.createElement(jt(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===i)this._$AH.p(e);else{const o=new le(i,this),n=o.u(this.options);o.p(e),this.T(n),this._$AH=o}}_$AC(t){let e=St.get(t.strings);return e===void 0&&St.set(t.strings,e=new nt(t)),e}k(t){dt(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let s,i=0;for(const o of t)i===e.length?e.push(s=new Bt(this.O(Y()),this.O(Y()),this,this.options)):s=e[i],s._$AI(o),i++;i<e.length&&(this._$AR(s&&s._$AB.nextSibling,i),e.length=i)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t!==this._$AB;){const s=t.nextSibling;t.remove(),t=s}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}},et=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,s,i,o){this.type=1,this._$AH=p,this._$AN=void 0,this.element=t,this.name=e,this._$AM=i,this.options=o,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=p}_$AI(t,e=this,s,i){const o=this.strings;let n=!1;if(o===void 0)t=H(this,t,e,0),n=!W(t)||t!==this._$AH&&t!==U,n&&(this._$AH=t);else{const l=t;let h,c;for(t=o[0],h=0;h<o.length-1;h++)c=H(this,l[s+h],e,h),c===U&&(c=this._$AH[h]),n||(n=!W(c)||c!==this._$AH[h]),c===p?t=p:t!==p&&(t+=(c??"")+o[h+1]),this._$AH[h]=c}n&&!i&&this.j(t)}j(t){t===p?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},ce=class extends et{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===p?void 0:t}},de=class extends et{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==p)}},pe=class extends et{constructor(t,e,s,i,o){super(t,e,s,i,o),this.type=5}_$AI(t,e=this){if((t=H(this,t,e,0)??p)===U)return;const s=this._$AH,i=t===p&&s!==p||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,o=t!==p&&(s===p||i);i&&this.element.removeEventListener(this.name,this,s),o&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}},ue=class{constructor(t,e,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(t){H(this,t)}};const $e=D.litHtmlPolyfillSupport;$e?.(nt,zt),(D.litHtmlVersions??(D.litHtmlVersions=[])).push("3.3.1");const G=globalThis,pt=G.ShadowRoot&&(G.ShadyCSS===void 0||G.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,ut=Symbol(),wt=new WeakMap;let Wt=class{constructor(t,e,s){if(this._$cssResult$=!0,s!==ut)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(pt&&t===void 0){const s=e!==void 0&&e.length===1;s&&(t=wt.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),s&&wt.set(e,t))}return t}toString(){return this.cssText}};const fe=r=>new Wt(typeof r=="string"?r:r+"",void 0,ut),_e=(r,...t)=>{const e=r.length===1?r[0]:t.reduce(((s,i,o)=>s+(n=>{if(n._$cssResult$===!0)return n.cssText;if(typeof n=="number")return n;throw Error("Value passed to 'css' function must be a 'css' function result: "+n+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+r[o+1]),r[0]);return new Wt(e,r,ut)},ge=(r,t)=>{if(pt)r.adoptedStyleSheets=t.map((e=>e instanceof CSSStyleSheet?e:e.styleSheet));else for(const e of t){const s=document.createElement("style"),i=G.litNonce;i!==void 0&&s.setAttribute("nonce",i),s.textContent=e.cssText,r.appendChild(s)}},Ct=pt?r=>r:r=>r instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return fe(e)})(r):r;const{is:me,defineProperty:Ae,getOwnPropertyDescriptor:ye,getOwnPropertyNames:ve,getOwnPropertySymbols:be,getPrototypeOf:Ee}=Object,v=globalThis,xt=v.trustedTypes,Se=xt?xt.emptyScript:"",we=v.reactiveElementPolyfillSupport,j=(r,t)=>r,ht={toAttribute(r,t){switch(t){case Boolean:r=r?Se:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,t){let e=r;switch(t){case Boolean:e=r!==null;break;case Number:e=r===null?null:Number(r);break;case Object:case Array:try{e=JSON.parse(r)}catch{e=null}}return e}},Vt=(r,t)=>!me(r,t),Pt={attribute:!0,type:String,converter:ht,reflect:!1,useDefault:!1,hasChanged:Vt};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),v.litPropertyMetadata??(v.litPropertyMetadata=new WeakMap);let T=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??(this.l=[])).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=Pt){if(e.state&&(e.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((e=Object.create(e)).wrapped=!0),this.elementProperties.set(t,e),!e.noAccessor){const s=Symbol(),i=this.getPropertyDescriptor(t,s,e);i!==void 0&&Ae(this.prototype,t,i)}}static getPropertyDescriptor(t,e,s){const{get:i,set:o}=ye(this.prototype,t)??{get(){return this[e]},set(n){this[e]=n}};return{get:i,set(n){const l=i?.call(this);o?.call(this,n),this.requestUpdate(t,l,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??Pt}static _$Ei(){if(this.hasOwnProperty(j("elementProperties")))return;const t=Ee(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(j("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(j("properties"))){const e=this.properties,s=[...ve(e),...be(e)];for(const i of s)this.createProperty(i,e[i])}const t=this[Symbol.metadata];if(t!==null){const e=litPropertyMetadata.get(t);if(e!==void 0)for(const[s,i]of e)this.elementProperties.set(s,i)}this._$Eh=new Map;for(const[e,s]of this.elementProperties){const i=this._$Eu(e,s);i!==void 0&&this._$Eh.set(i,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const s=new Set(t.flat(1/0).reverse());for(const i of s)e.unshift(Ct(i))}else t!==void 0&&e.push(Ct(t));return e}static _$Eu(t,e){const s=e.attribute;return s===!1?void 0:typeof s=="string"?s:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach((t=>t(this)))}addController(t){(this._$EO??(this._$EO=new Set)).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const s of e.keys())this.hasOwnProperty(s)&&(t.set(s,this[s]),delete this[s]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return ge(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),this._$EO?.forEach((t=>t.hostConnected?.()))}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach((t=>t.hostDisconnected?.()))}attributeChangedCallback(t,e,s){this._$AK(t,s)}_$ET(t,e){const s=this.constructor.elementProperties.get(t),i=this.constructor._$Eu(t,s);if(i!==void 0&&s.reflect===!0){const o=(s.converter?.toAttribute!==void 0?s.converter:ht).toAttribute(e,s.type);this._$Em=t,o==null?this.removeAttribute(i):this.setAttribute(i,o),this._$Em=null}}_$AK(t,e){const s=this.constructor,i=s._$Eh.get(t);if(i!==void 0&&this._$Em!==i){const o=s.getPropertyOptions(i),n=typeof o.converter=="function"?{fromAttribute:o.converter}:o.converter?.fromAttribute!==void 0?o.converter:ht;this._$Em=i;const l=n.fromAttribute(e,o.type);this[i]=l??this._$Ej?.get(i)??l,this._$Em=null}}requestUpdate(t,e,s){if(t!==void 0){const i=this.constructor,o=this[t];if(s??(s=i.getPropertyOptions(t)),!((s.hasChanged??Vt)(o,e)||s.useDefault&&s.reflect&&o===this._$Ej?.get(t)&&!this.hasAttribute(i._$Eu(t,s))))return;this.C(t,e,s)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(t,e,{useDefault:s,reflect:i,wrapped:o},n){s&&!(this._$Ej??(this._$Ej=new Map)).has(t)&&(this._$Ej.set(t,n??e??this[t]),o!==!0||n!==void 0)||(this._$AL.has(t)||(this.hasUpdated||s||(e=void 0),this._$AL.set(t,e)),i===!0&&this._$Em!==t&&(this._$Eq??(this._$Eq=new Set)).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[i,o]of this._$Ep)this[i]=o;this._$Ep=void 0}const s=this.constructor.elementProperties;if(s.size>0)for(const[i,o]of s){const{wrapped:n}=o,l=this[i];n!==!0||this._$AL.has(i)||l===void 0||this.C(i,void 0,o,l)}}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach((s=>s.hostUpdate?.())),this.update(e)):this._$EM()}catch(s){throw t=!1,this._$EM(),s}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach((e=>e.hostUpdated?.())),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&(this._$Eq=this._$Eq.forEach((e=>this._$ET(e,this[e])))),this._$EM()}updated(t){}firstUpdated(t){}};T.elementStyles=[],T.shadowRootOptions={mode:"open"},T[j("elementProperties")]=new Map,T[j("finalized")]=new Map,we?.({ReactiveElement:T}),(v.reactiveElementVersions??(v.reactiveElementVersions=[])).push("2.1.1");const I=globalThis,tt=I.trustedTypes,Tt=tt?tt.createPolicy("lit-html",{createHTML:r=>r}):void 0,qt="$lit$",A=`lit$${Math.random().toFixed(9).slice(2)}$`,Ft="?"+A,Ce=`<${Ft}>`,x=document,V=()=>x.createComment(""),q=r=>r===null||typeof r!="object"&&typeof r!="function",$t=Array.isArray,xe=r=>$t(r)||typeof r?.[Symbol.iterator]=="function",ot=`[ 	
\f\r]`,R=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Ut=/-->/g,Ht=/>/g,E=RegExp(`>|${ot}(?:([^\\s"'>=/]+)(${ot}*=${ot}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Mt=/'/g,Ot=/"/g,Jt=/^(?:script|style|textarea|title)$/i,Pe=r=>(t,...e)=>({_$litType$:r,strings:t,values:e}),g=Pe(1),M=Symbol.for("lit-noChange"),$=Symbol.for("lit-nothing"),Nt=new WeakMap,w=x.createTreeWalker(x,129);function Kt(r,t){if(!$t(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return Tt!==void 0?Tt.createHTML(t):t}const Te=(r,t)=>{const e=r.length-1,s=[];let i,o=t===2?"<svg>":t===3?"<math>":"",n=R;for(let l=0;l<e;l++){const h=r[l];let c,d,a=-1,u=0;for(;u<h.length&&(n.lastIndex=u,d=n.exec(h),d!==null);)u=n.lastIndex,n===R?d[1]==="!--"?n=Ut:d[1]!==void 0?n=Ht:d[2]!==void 0?(Jt.test(d[2])&&(i=RegExp("</"+d[2],"g")),n=E):d[3]!==void 0&&(n=E):n===E?d[0]===">"?(n=i??R,a=-1):d[1]===void 0?a=-2:(a=n.lastIndex-d[2].length,c=d[1],n=d[3]===void 0?E:d[3]==='"'?Ot:Mt):n===Ot||n===Mt?n=E:n===Ut||n===Ht?n=R:(n=E,i=void 0);const f=n===E&&r[l+1].startsWith("/>")?" ":"";o+=n===R?h+Ce:a>=0?(s.push(c),h.slice(0,a)+qt+h.slice(a)+A+f):h+A+(a===-2?l:f)}return[Kt(r,o+(r[e]||"<?>")+(t===2?"</svg>":t===3?"</math>":"")),s]};class F{constructor({strings:t,_$litType$:e},s){let i;this.parts=[];let o=0,n=0;const l=t.length-1,h=this.parts,[c,d]=Te(t,e);if(this.el=F.createElement(c,s),w.currentNode=this.el.content,e===2||e===3){const a=this.el.content.firstChild;a.replaceWith(...a.childNodes)}for(;(i=w.nextNode())!==null&&h.length<l;){if(i.nodeType===1){if(i.hasAttributes())for(const a of i.getAttributeNames())if(a.endsWith(qt)){const u=d[n++],f=i.getAttribute(a).split(A),_=/([.?@])?(.*)/.exec(u);h.push({type:1,index:o,name:_[2],strings:f,ctor:_[1]==="."?He:_[1]==="?"?Me:_[1]==="@"?Oe:st}),i.removeAttribute(a)}else a.startsWith(A)&&(h.push({type:6,index:o}),i.removeAttribute(a));if(Jt.test(i.tagName)){const a=i.textContent.split(A),u=a.length-1;if(u>0){i.textContent=tt?tt.emptyScript:"";for(let f=0;f<u;f++)i.append(a[f],V()),w.nextNode(),h.push({type:2,index:++o});i.append(a[u],V())}}}else if(i.nodeType===8)if(i.data===Ft)h.push({type:2,index:o});else{let a=-1;for(;(a=i.data.indexOf(A,a+1))!==-1;)h.push({type:7,index:o}),a+=A.length-1}o++}}static createElement(t,e){const s=x.createElement("template");return s.innerHTML=t,s}}function O(r,t,e=r,s){if(t===M)return t;let i=s!==void 0?e._$Co?.[s]:e._$Cl;const o=q(t)?void 0:t._$litDirective$;return i?.constructor!==o&&(i?._$AO?.(!1),o===void 0?i=void 0:(i=new o(r),i._$AT(r,e,s)),s!==void 0?(e._$Co??(e._$Co=[]))[s]=i:e._$Cl=i),i!==void 0&&(t=O(r,i._$AS(r,t.values),i,s)),t}class Ue{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:s}=this._$AD,i=(t?.creationScope??x).importNode(e,!0);w.currentNode=i;let o=w.nextNode(),n=0,l=0,h=s[0];for(;h!==void 0;){if(n===h.index){let c;h.type===2?c=new J(o,o.nextSibling,this,t):h.type===1?c=new h.ctor(o,h.name,h.strings,this,t):h.type===6&&(c=new Ne(o,this,t)),this._$AV.push(c),h=s[++l]}n!==h?.index&&(o=w.nextNode(),n++)}return w.currentNode=x,i}p(t){let e=0;for(const s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(t,s,e),e+=s.strings.length-2):s._$AI(t[e])),e++}}class J{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,s,i){this.type=2,this._$AH=$,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=s,this.options=i,this._$Cv=i?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return e!==void 0&&t?.nodeType===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=O(this,t,e),q(t)?t===$||t==null||t===""?(this._$AH!==$&&this._$AR(),this._$AH=$):t!==this._$AH&&t!==M&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):xe(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==$&&q(this._$AH)?this._$AA.nextSibling.data=t:this.T(x.createTextNode(t)),this._$AH=t}$(t){const{values:e,_$litType$:s}=t,i=typeof s=="number"?this._$AC(t):(s.el===void 0&&(s.el=F.createElement(Kt(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===i)this._$AH.p(e);else{const o=new Ue(i,this),n=o.u(this.options);o.p(e),this.T(n),this._$AH=o}}_$AC(t){let e=Nt.get(t.strings);return e===void 0&&Nt.set(t.strings,e=new F(t)),e}k(t){$t(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let s,i=0;for(const o of t)i===e.length?e.push(s=new J(this.O(V()),this.O(V()),this,this.options)):s=e[i],s._$AI(o),i++;i<e.length&&(this._$AR(s&&s._$AB.nextSibling,i),e.length=i)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t!==this._$AB;){const s=t.nextSibling;t.remove(),t=s}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}}class st{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,s,i,o){this.type=1,this._$AH=$,this._$AN=void 0,this.element=t,this.name=e,this._$AM=i,this.options=o,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=$}_$AI(t,e=this,s,i){const o=this.strings;let n=!1;if(o===void 0)t=O(this,t,e,0),n=!q(t)||t!==this._$AH&&t!==M,n&&(this._$AH=t);else{const l=t;let h,c;for(t=o[0],h=0;h<o.length-1;h++)c=O(this,l[s+h],e,h),c===M&&(c=this._$AH[h]),n||(n=!q(c)||c!==this._$AH[h]),c===$?t=$:t!==$&&(t+=(c??"")+o[h+1]),this._$AH[h]=c}n&&!i&&this.j(t)}j(t){t===$?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class He extends st{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===$?void 0:t}}class Me extends st{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==$)}}class Oe extends st{constructor(t,e,s,i,o){super(t,e,s,i,o),this.type=5}_$AI(t,e=this){if((t=O(this,t,e,0)??$)===M)return;const s=this._$AH,i=t===$&&s!==$||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,o=t!==$&&(s===$||i);i&&this.element.removeEventListener(this.name,this,s),o&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class Ne{constructor(t,e,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(t){O(this,t)}}const ke=I.litHtmlPolyfillSupport;ke?.(F,J),(I.litHtmlVersions??(I.litHtmlVersions=[])).push("3.3.1");const Re=(r,t,e)=>{const s=e?.renderBefore??t;let i=s._$litPart$;if(i===void 0){const o=e?.renderBefore??null;s._$litPart$=i=new J(t.insertBefore(V(),o),o,void 0,e??{})}return i._$AI(r),i};const z=globalThis;let B=class extends T{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e;const t=super.createRenderRoot();return(e=this.renderOptions).renderBefore??(e.renderBefore=t.firstChild),t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=Re(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return M}};B._$litElement$=!0,B.finalized=!0,z.litElementHydrateSupport?.({LitElement:B});const Le=z.litElementPolyfillSupport;Le?.({LitElement:B});(z.litElementVersions??(z.litElementVersions=[])).push("4.2.1");const De=r=>(t,e)=>{e!==void 0?e.addInitializer((()=>{customElements.define(r,t)})):customElements.define(r,t)};const je={attribute:!0,type:String,converter:Q,reflect:!1,hasChanged:ct},Ie=(r=je,t,e)=>{const{kind:s,metadata:i}=e;let o=globalThis.litPropertyMetadata.get(i);if(o===void 0&&globalThis.litPropertyMetadata.set(i,o=new Map),s==="setter"&&((r=Object.create(r)).wrapped=!0),o.set(e.name,r),s==="accessor"){const{name:n}=e;return{set(l){const h=t.get.call(this);t.set.call(this,l),this.requestUpdate(n,h,r)},init(l){return l!==void 0&&this.C(n,void 0,r,l),l}}}if(s==="setter"){const{name:n}=e;return function(l){const h=this[n];t.call(this,l),this.requestUpdate(n,h,r)}}throw Error("Unsupported decorator location: "+s)};function ze(r){return(t,e)=>typeof e=="object"?Ie(r,t,e):((s,i,o)=>{const n=i.hasOwnProperty(o);return i.constructor.createProperty(o,s),n?Object.getOwnPropertyDescriptor(i,o):void 0})(r,t,e)}function it(r){return ze({...r,state:!0,attribute:!1})}const Be={CHILD:2},We=r=>(...t)=>({_$litDirective$:r,values:t});class Ve{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,s){this._$Ct=t,this._$AM=e,this._$Ci=s}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}}class at extends Ve{constructor(t){if(super(t),this.it=p,t.type!==Be.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(t){if(t===p||t==null)return this._t=void 0,this.it=t;if(t===U)return t;if(typeof t!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(t===this.it)return this._t;this.it=t;const e=[t];return e.raw=e,this._t={_$litType$:this.constructor.resultType,strings:e,values:[]}}}at.directiveName="unsafeHTML",at.resultType=1;const qe=We(at);var Fe=Object.defineProperty,Je=Object.getOwnPropertyDescriptor,K=(r,t,e,s)=>{for(var i=s>1?void 0:s?Je(t,e):t,o=r.length-1,n;o>=0;o--)(n=r[o])&&(i=(s?n(t,e,i):n(i))||i);return s&&i&&Fe(t,e,i),i};let P=class extends B{constructor(){super(...arguments),this._fragments=[],this._selectedId=null,this._isLoading=!0,this._error=null}async connectedCallback(){super.connectedCallback(),await this.fetchFragmentData()}async fetchFragmentData(){this._isLoading=!0,this._error=null;try{const r=window.Liferay?.authToken,t=window.Liferay?.ThemeDisplay.getSiteGroupId();if(!r||!t)throw new Error("Liferay context (authToken or siteId) not found.");const e=`/o/c/fragmentdetails/scopes/${t}?sort=fragmentName:asc`,s=await fetch(e,{headers:{"x-csrf-token":r,"Content-Type":"application/json"}});if(!s.ok)throw new Error(`API Error: ${s.status} ${s.statusText}`);const i=await s.json();this._fragments=i.items||[]}catch(r){console.error(r),this._error=r.message||"Failed to fetch fragment data."}finally{this._isLoading=!1}}_handleSelect(r){this._selectedId=r}_copyToClipboard(r,t){const e=t.currentTarget;navigator.clipboard.writeText(r).then(()=>{e.classList.add("copied"),e.innerHTML="Copied!",e.disabled=!0,setTimeout(()=>{e.classList.remove("copied"),e.innerHTML="📋 Copy",e.disabled=!1},1500)}).catch(s=>{console.error("Failed to copy text: ",s),e.innerHTML="Error!",setTimeout(()=>{e.innerHTML="📋 Copy"},1500)})}_renderLayout(){const r=this._fragments.find(t=>t.id===this._selectedId);return g`
      <div class="container">
        <div class="list-panel">
          ${this._fragments.map(t=>g`
              <div
                class="list-item ${t.id===this._selectedId?"selected":""}"
                @click=${()=>this._handleSelect(t.id)}
              >
                <strong>${t.fragmentName}</strong>
                <p>${t.description}</p>
              </div>
            `)}
        </div>

        <div class="detail-panel">
          ${r?this._renderDetail(r):g`<div class="placeholder">Select a fragment from the list to see its details.</div>`}
        </div>
      </div>
    `}_renderDetail(r){return g`
      <div class="detail-content">
        <h2>${r.fragmentName}</h2>
        <p class="description">${r.description}</p>
        
        <h3>Usage Details</h3>
        <div class="usage-details">
          ${qe(r.usageSteps)}
        </div>

        ${this._renderCodeBlock("Configuration",r.configuration)}
        ${this._renderCodeBlock("JavaScript",r.javaScript)}
        ${this._renderCodeBlock("HTML",r.html)}
        ${this._renderCodeBlock("CSS",r.css)}
      </div>
    `}_renderCodeBlock(r,t){return!t||t.trim()===""?$:g`
      <div class="code-block">
        <div class="header">
          <strong>${r}</strong>
          <button class="copy-btn" @click=${e=>this._copyToClipboard(t,e)}>
            📋 Copy
          </button>
        </div>
        <pre><code>${t}</code></pre>
      </div>
    `}render(){return this._isLoading?g`<p>Loading fragments...</p>`:this._error?g`<p class="error"><strong>Error:</strong> ${this._error}</p>`:this._fragments.length===0?g`<p>No fragments found.</p>`:this._renderLayout()}};P.styles=_e`
    :host {
      display: block;
      font-family: Arial, sans-serif;
      border: 1px solid #ccc;
      border-radius: 8px;
      overflow: hidden;
      height: 70vh;
      min-height: 400px;
    }

    .container {
      display: flex;
      height: 100%;
    }

    /* --- Left List Panel --- */

    .list-panel {
      width: 35%;
      min-width: 250px;
      background: #f9f9f9;
      border-right: 1px solid #ccc;
      overflow-y: auto;
    }

    .list-item {
      padding: 1rem;
      border-bottom: 1px solid #eee;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .list-item:hover {
      background-color: #f0f0f0;
    }

    .list-item.selected {
      background-color: #e0eafc;
      border-left: 4px solid #005fff;
      padding-left: calc(1rem - 4px);
    }

    .list-item p {
      font-size: 0.9em;
      color: #555;
      margin: 0.25rem 0 0 0;
      white-space: normal;
      word-break: break-word;
    }

    /* --- Right Detail Panel --- */

    .detail-panel {
      flex: 1;
      overflow-y: auto;
    }
    
    .detail-content {
       padding: 1.5rem;
    }

    .placeholder {
      padding: 2rem;
      text-align: center;
      color: #777;
      font-size: 1.1em;
    }
    
    h2 {
      margin-top: 0;
    }
    
    .description {
      font-size: 1.1em;
      color: #333;
      border-bottom: 1px solid #eee;
      padding-bottom: 1rem;
    }

    /* --- Code Block --- */

    .code-block {
      margin: 1.5rem 0;
      border: 1px solid #ddd;
      border-radius: 4px;
    }

    .code-block .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f7f7f7;
      padding: 0.5rem 1rem;
      border-bottom: 1px solid #ddd;
    }
    
    .copy-btn {
      font-size: 0.8em;
      padding: 0.25rem 0.5rem;
      border: 1px solid #ccc;
      border-radius: 4px;
      background: #fff;
      cursor: pointer;
      transition: background-color 0.2s, color 0.2s;
    }
    
    .copy-btn.copied {
      background-color: #ccebc5;
      border-color: #a8dba3;
      color: #276221;
    }

    pre {
      margin: 0;
      background: #fafafa;
      padding: 1rem;
      overflow-x: auto;
      max-height: 300px;
      font-family: 'Courier New', Courier, monospace;
    }
    
    code {
      font-size: 0.9em;
    }

    /* --- Usage Details --- */

    .usage-details {
      margin-top: 0.5rem; /* Reduced margin a bit */
      margin-bottom: 1.5rem; /* Added margin to separate from code blocks */
      padding-bottom: 1.5rem; /* Added padding */
      border-bottom: 1px solid #eee; /* Separator */
    }

    .usage-details p {
      line-height: 1.6;
      margin-top: 0;
    }

    .usage-details code {
      background: #f0f0f0;
      padding: 2px 4px;
      border-radius: 3px;
    }
    
    .error {
      color: #d8000c;
      background-color: #ffbaba;
      border: 1px solid #d8000c;
      padding: 1rem;
      margin: 1rem;
    }
  `;K([it()],P.prototype,"_fragments",2);K([it()],P.prototype,"_selectedId",2);K([it()],P.prototype,"_isLoading",2);K([it()],P.prototype,"_error",2);P=K([De("fragment-viewer")],P);
